*******
bioCalc
*******

General Information
####################

bioCalc is a biological calculator

.. image:: /docs/test.png
    :alt: test



